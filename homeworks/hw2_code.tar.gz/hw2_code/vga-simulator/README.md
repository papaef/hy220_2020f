# VGA Simulator

Use the tool online now, http://ericeastwood.com/lab/vga-simulator/

See this blog post for more info and how to use: http://ericeastwood.com/blog/8/vga-simulator-getting-started

![](http://i.imgur.com/e5XkXp6.png)

---

The code is a bit crusty and old now but happy to have it on GitHub. It could also use a lot of optimization to make it faster, feel free to submit a PR.


## Python port (CLI)

[Pedro, @pvieito](https://github.com/pvieito) made a CLI version of this app in Python that you can find in [this gist](https://gist.github.com/pvieito/8cdb54a9a03fd36e51c8df6e331a3006).
